<?php
    include('connection.php');
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Se connecter Mini Facebook</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
    <div id="page">
        <h1>Mini Facebook </h1>
        <p><a href="listedemembres.php">La liste des membres</a></p>
        <h2>Connexion</h2>
        <form action="login-traitement.php" method='post'>
        <p style="text-align: center"> 
			<?php if(isset($_GET['erreur']))  { ?>
	            L'adresse email ou le mot de passe est incorrect, veuillez réessayer
	        <?php }  ?>
	    </p>
        <p>email : <input type="text" name="email"></p>
        <p>mot de passe : <input type="password" name="motdepasse"></p>
        <p><input type="submit" value="Se Connecter"></p>
        </form>
        <p><a href="oublie.php">Mot de passe oublié</a></p>
        <p>Vous n'avez pas de compte?<a href="inscription.php">Cliquer ici pour vous inscrire</a></p>
        <p><a href="index.php"><< Retour</a></p>
    </div>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>