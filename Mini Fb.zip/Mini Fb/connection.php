<?php
    $bdd=mysqli_connect('localhost', 'root' , 'root', 'minifb');
    mysqli_set_charset($bdd, "utf8");
?>