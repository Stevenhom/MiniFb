<?php
	include('connection.php');
	session_start();
	$ip3=$_GET['ip2'];

	$email=$_SESSION['email'];
	$motdepasse=$_SESSION['motdepasse'];
	$sq="SELECT * FROM membres WHERE email='%s';";
	$sq=sprintf($sq, $email);
	$resul=mysqli_query($bdd, $sq);
	$row=mysqli_fetch_assoc($resul);

	$id=$row['idmembre'];
	$text=$_POST['message'];
	$sql="INSERT INTO message(id_mandray,id_mandefa,contenu) VALUES('%s','%s', '%s');";
	$sql=sprintf($sql, $ip3, $id, $text);
	echo $sql;
	$result=mysqli_query($bdd, $sql);
	
	header("Location:message.php?mess=".$ip3);

?>