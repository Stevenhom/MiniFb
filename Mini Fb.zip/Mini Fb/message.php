<?php
    include('connection.php');
	session_start();
	$email=$_SESSION['email'];
	$motdepasse=$_SESSION['motdepasse'];
	$sql="SELECT * FROM membres WHERE email='%s';";
	$sql=sprintf($sql, $email);
	$result=mysqli_query($bdd, $sql);
	
	$sql1="SELECT * FROM message;";
	$result1=mysqli_query($bdd, $sql1);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Chat</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
	</head>
	<body>
		<?php while ($row=mysqli_fetch_assoc($result1)) { ?>
		<form method="POST" action="accept.php?ip2=<?php echo $_GET['mess'] ; ?>">
         <p><?php echo $row['contenu']; ?></p>
         <?php } ?>
         <br />
         <textarea placeholder="Votre message" name="message"></textarea>
         <br />
         <input type="submit" value="Envoyer" name="envoi_message" />
         <br /><br />
      </form>
      <br />
		<p><a href="chat.php"><< retour</a></p>
		<p><a href="accueil.php"><< retour a l'acceuil</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
	</body>
</html>