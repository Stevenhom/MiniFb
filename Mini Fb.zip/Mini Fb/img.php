<?php
    include('connection.php');
	session_start();
	$email=$_SESSION['email'];
	$motdepasse=$_SESSION['motdepasse'];
	$sql="SELECT * FROM membres WHERE email='%s';";
	$sql=sprintf($sql, $email);
	$result=mysqli_query($bdd, $sql);
	$row=mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Accueil</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
       <h1>Mini Facebook</h1>
       <h2><?php echo $row['nom']; ?>, Veuillez choisir votre avatar</h2>
	   <form method="POST" action="maka.php" enctype="multipart/form-data">
            <!-- On limite le fichier à 100Ko -->     
            <input type="hidden" name="MAX_FILE_SIZE" value="100000">     
  Fichier : <input type="file" name="avatar"> 
            <input type="submit" name="envoyer" value="Valider"> 
       </form> 
    <p><a href="accueil.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>