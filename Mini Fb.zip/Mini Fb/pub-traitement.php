<?php
    session_start();
    include('connection.php');
    $sentiment=isset($_POST['sentiment'])? $_POST['sentiment']:'';
    $pub=isset($_POST['pub'])? $_POST['pub']:'';
    $affichage=isset($_POST['affichage'])? $_POST['affichage']:'';
    $sql="INSERT INTO publications(dateheurepublication, textepublication, typeaffichage, sentiment, idmembre) VALUES(current_timestamp, '%s', '%s', '%s', '%d');";
    $sql=sprintf($sql, $pub, $affichage, $sentiment, $_SESSION['id']);
    $post=mysqli_query($bdd, $sql);
    $id=$_SESSION['id'];
    $sql2="SELECT * FROM publications JOIN membres ON publications.idmembre=membres.idmembre WHERE textepublication='%s' and membres.idmembre='%d';";
    $sql2=sprintf($sql2, $pub, $id);
    $row=mysqli_query($bdd, $sql2);
    $donnees=mysqli_fetch_assoc($row);
    $_SESSION['idp']=0;
    $_SESSION['idp']=$donnees['idpublication'];
    header('Location: pub.php');

 ?>