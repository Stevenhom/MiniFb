<?php
    session_start();
    include('connection.php');
    $idpublication=isset($_GET['idpublication'])? $_GET['idpublication']:$_SESSION['idp'];
    $sql="SELECT * FROM publications JOIN membres ON publications.idmembre=membres.idmembre WHERE idpublication='%d'";
    $sql=sprintf($sql, $idpublication);
    $result=mysqli_query($bdd, $sql);
    $donnees=mysqli_fetch_assoc($result);
    date_default_timezone_set("Indian/Antananarivo");
    $date=date_create($donnees['dateheurepublication']);
    $sql2="SELECT * FROM commentaires JOIN membres on commentaires.idmembre=membres.idmembre WHERE idpublication='%d' ORDER BY idcommentaires";
    $sql2=sprintf($sql2, $idpublication);
    $commentaire=mysqli_query($bdd, $sql2);
    $_SESSION['idpub']=$idpublication;
    $type=mysqli_query($bdd, "SELECT * FROM typereaction ORDER BY idtype");
    $sql3="SELECT * FROM reactios JOIN typereaction ON idtypereaction=idtype WHERE idpublication='%s' AND idmembre='%s';";
    $sql3=sprintf($sql3, $idpublication, $_SESSION['id']);
    $reaction=mysqli_query($bdd, $sql3);
    $reactrow=mysqli_fetch_assoc($reaction);
    $_SESSION['reaction']=0;
    if($reactrow['idmembre']==$_SESSION['id']){
    $_SESSION['reaction']=1;
    $_SESSION['myreact']=$reactRow['idtype']; }

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Accueil</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
       <h1>Mini Facebook</h1>
      
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>