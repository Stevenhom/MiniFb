<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Mini Facebook</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
    <h1>Mini Facebook</h1>
    <h2>Rechercher un membre</h2>
    <form action="recherche-resultat.php" method="GET">
    <p>Nom : <input type="text" name="nom"> <input type="submit" value="Rechercher"></p>
    </form>
    <p><a href="accueil.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>