<?php
	include('connection.php');
	session_start();
	$email=$_SESSION['email'];
	$motdepasse=$_SESSION['motdepasse'];
	$sql1="SELECT * FROM membres WHERE email='%s';";
	$sql1=sprintf($sql1, $email);
	$result1=mysqli_query($bdd, $sql1);
	$row=mysqli_fetch_assoc($result1);

	$sql="SELECT * FROM membres;";
	$result=mysqli_query($bdd, $sql);
	
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Chat</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
    <h1>Message</h1>
	<table border='0'>
		<?php while ($row=mysqli_fetch_assoc($result)) { ?>
		<tr>
			<td><img src="<?php echo $row['image'] ?>" width="50px"></td>
			<td><?php echo $row['nom'] ?></td>
			<td><a href="message.php?mess=<?php echo $row['idmembre'] ?>">message</a></td>
		</tr>
		<?php } ?>
	</table>
    <p><a href="accueil.php"><< retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>