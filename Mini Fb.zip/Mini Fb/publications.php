<?php
    include('connection.php');
    session_start();
    $sql="SELECT * FROM publications JOIN membres ON publications.idmembre=membres.idmembre;";
    $result=mysqli_query($bdd, $sql);
    $sql2="SELECT * FROM publications JOIN membres ON publications.idmembre=membres.idmembre;";
    $result2=mysqli_query($bdd, $sql2);
    $i=0;
    $j=0;
    $temoin=0;
    $_SESSION['ami'][0]=0;
    date_default_timezone_set("Indian/Antananarivo");
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Accueil</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
       <h1>Mini Facebook</h1>
       <h2>Les publications</h2>
       <table border="1">
  <tr>
    <th>Id</th>
    <th>Publié par</th>
    <th>Publication</th>
    <th>Posté le</th>
    <th>Option</th>
      </tr>
<?php
  while($donnees=mysqli_fetch_assoc($result)){?>
    <?php $date=date_create($donnees['dateheurepublication']); ?>

   <?php $sql3="SELECT * FROM amis WHERE idmembre1='%d' OR imembre2='%d'";
   $sql3=sprintf($sql3, $donnees['idmembre'], $donnees['idmembre']);
   $ami=mysqli_query($bdd, $sql3); ?>
   <?php while($data=mysqli_fetch_assoc($ami)){ ?>
    <?php if(($data['idmembre1']==$_SESSION['id']||$data['idmembre2']==$_SESSION['id'])&&$data['dateHeureacceptation']!=NULL){ ?>
  <tr>
  <td><?php echo $donnees['idpublication'];?></td>
  <td><?php echo $donnees['nom'];?></a></td>
  <td><?php echo $donnees['textepublication']; ?> </td>
  <td><?php echo date_format($date, 'd/m/Y à H:i:s') ?></td>
  <td><a href="pub.php?idpublication=<?php echo $donnees['idpublication']?>">Voir plus</a></td><?php $_SESSION['ami'][$i]=$donnees['IdPublication'];
  $i++;
  if($donnees['idmembre']==$_SESSION['id']){break;}
  }}} ?></tr>

  <?php
  while($data2=mysqli_fetch_assoc($result2)){$temoin=0; ?>
        <?php $date2=date_create($data2['dateheurepublication']); ?>


      <?php while($j<=$i-1){ ?>
      <?php if ($data2['idpublication']==$_SESSION['ami'][$j]){ $j++; $temoin=1; break; } else {break; }} ?>
      <?php if ($data2['typeaffichage']=='public'){ ?>
      <?php if($temoin==0){ ?>
         <tr>
    <td><?php echo $data2['idpublication'];?></td>
    <td><?php echo $data2['nom'];?></a></td>
    <td><?php echo $data2['textepublication']; ?> </td>
    <td><?php echo date_format($date2, 'd/m/Y à H:i:s') ?></td>
  <td><a href="pub.php?idpublication=<?php echo $data2['idpublication']?>">Voir plus</a></td><?php }}} ?>
</table>
        <p><a href="accueil.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>