<?php
	include('connection.php');
	$sql="SELECT * FROM membres;";
	$result=mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Liste des membres</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
    <h1>Mini Facebook</h1>
    <h2>La liste des membres : </h2>
	<table width='900' border='1'>
		<tr>
			<th>idmembre</th>
			<th>email</th>
			<th>nom</th>
		</tr>
		<?php while ($row=mysqli_fetch_assoc($result)) { ?>
		<tr>
			<td><?php echo $row['idmembre'] ?></td>
			<td><?php echo $row['email'] ?></td>
			<td><?php echo $row['nom'] ?></td>
		</tr>
		<?php } ?>
	</table>
    <p><a href="login.php"><< retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>