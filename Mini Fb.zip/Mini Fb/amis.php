<?php
    session_start();
    include('connection.php');
    $sql="SELECT * FROM membres JOIN amis ON idmembre1=idmembre;";
    $result=mysqli_query($bdd, $sql);
    $sql2="SELECT * FROM membres ";
    $result2=mysqli_query($bdd, $sql2);
    $sql3="SELECT * FROM membres JOIN amis ON idmembre2=idmembre;";
    $result3=mysqli_query($bdd, $sql3);
    $_SESSION['accepter'][0]='';
    $_SESSION['annuler'][0]='';
    $i=0;
    $j=0;
    $k=0;
    $l=0;
    $temoin=0;
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Accueil</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
       <h1>Mini Facebook</h1>
       <h2>Vos Amis, Vos demandes, Vos suggestions</h2>
       <table border="1">
    <tr>
        <th>Id</th>
        <th>Nom</th>
        <th>Option</th>
    </tr>
    <?php while($donnees=mysqli_fetch_assoc($result)) { ?>
        <?php if($donnees['idmembre']!=$_SESSION['id']&&$donnees['idmembre2']==$_SESSION['id']&&$donnees['dateheuredemande']!=NULL) { ?>
    <tr>
    <td><?php echo $donnees['idmembre'];?></td>
    <td><?php echo $donnees['nom']; ?></td>
        <?php if($donnees['dateheureacceptation']==NULL) { ?>
    <td><a href="amis-accepter.php?idmembre=<?php echo $donnees['idmembre']?>">Accepter demande</a></td><?php $_SESSION['accepter'][$i]=$donnees['idmembre'];
    $i++; }
        if($donnees['dateheureacceptation']!=NULL) { ?>
    <td>Vous êtes amis</td><?php $_SESSION['accepter'][$i]=$donnees['idmembre'];
    $i++; }}} ?>
    </tr>

    <?php while($donnees3=mysqli_fetch_assoc($result3)) { ?>
        <?php if($donnees3['idmembre']!=$_SESSION['id']&&$donnees3['idmembre1']==$_SESSION['id']&&$donnees3['dateheuredemande']!=NULL) { ?>
    <tr>
        <td><?php echo $donnees3['idmembre'];?></td>
        <td><?php echo $donnees3['nom'];?></td>
            <?php if($donnees3['dateheureacceptation']==NULL) { ?>
        <td><a href="amis-annuler.php?idmembre=<?php echo $donnees3['idmembre']?>">Annuler demande</a></td><?php $_SESSION['annuler'][$k]=$donnees3['idmembre'];
        $k++;}
        if($donnees3['dateheureacceptation']!=NULL) { ?>
        <td>Vous êtes amis</td><?php $_SESSION['annuler'][$k]=$donnees3['idmembre'];
        $k++; }
        }} ?>
    </tr>

    <?php while($data=mysqli_fetch_assoc($result2)) { $temoin=0; ?>
        <?php while($j<=$i-1) { ?>
            <?php if($data['idmembre']==$_SESSION['accepter'][$j]) { $j++; $temoin=1; break; } else {break; }} ?>

    <?php while($l<=$k-1) { ?>
        <?php if($data['idmembre']==$_SESSION['annuler'][$l]){ $l++; $temoin=1; break; } else {break; }} ?>

    <?php if($temoin==0){ ?>
    <tr>
    <td><?php echo $data['idmembre'];?></td>
    <td><?php echo $data['nom']; ?> </td>
        <?php if($data['idmembre']!=$_SESSION['id']) { ?>
    <td><a href="amis-ajouter.php?idmembre=<?php echo $data['idmembre']?>">Ajouter ami</a></td><?php }}} ?>
    </tr>
</table>
<p><a href="accueil.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>