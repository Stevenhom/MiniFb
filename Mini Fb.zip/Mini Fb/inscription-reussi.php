<?php
   include('connection.php');
   session_start();
   $idmembre=$_SESSION['idmembre'];
   $email=$_SESSION['email'];
   $motdepasse=$_SESSION['motdepasse'];
   $motdepasseconf=$_SESSION['motdepasseconf'];
   $nom=$_SESSION['nom'];
   $datenaissance=$_SESSION['datenaissance'];
   $sql="INSERT INTO membres VALUES('%i','', '%s', '%s', '%s', '%s');";
   $sql=sprintf($sql, $idmembre,  $email, $motdepasse, $nom, $datenaissance);
   $result=mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Se connecter Mini Facebook</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
        <h1>Mini Facebook</h1>
        <p><a href="listedemembres.php">La liste des membres</a></p>
        <h2>Inscription</h2>
        <p>Votre inscription est réussie,<a href="login.php">cliquer ici pour vous connecter</a></p>
        <p><a href="login.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>