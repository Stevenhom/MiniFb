<?php
    include('connection.php');
    session_start();
    $_SESSION["email"]=$_POST['email'];
    $email=$_SESSION["email"];
    $_SESSION["motdepasse"]=$_POST['motdepasse'];
    $motdepasse=$_SESSION["motdepasse"];
    $_SESSION['id']=0;
    $sql="SELECT email, motdepasse FROM membres;";
    $result=mysqli_query($bdd, $sql);
    while($membre=mysqli_fetch_assoc($result)) {
        if($email==$membre['email'] && $motdepasse==$membre['motdepasse']) {
            $_SESSION['id']=$row['idmembre'];
            header('Location:accueil.php');
            break;
        }
        else {
            header('Location:login.php?erreur=1');
        }
    }
?>