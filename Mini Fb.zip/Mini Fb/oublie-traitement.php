<?php
    include('connection.php');
    session_start();
    $_SESSION['email']=$_POST['email'];
	$email=$_SESSION['email'];
    $_SESSION['motdepasse']=$_POST['motdepasse'];
	$motdepasse=$_SESSION['motdepasse'];
	$_SESSION['motdepasseconf']=$_POST['motdepasseconf'];
	$motdepasseconf=$_SESSION['motdepasseconf'];
    $sql="SELECT * FROM membres;";
	$result=mysqli_query($bdd, $sql);
    while($row=mysqli_fetch_assoc($result)) {
        if($email==$row['email']) {
        header('Location:oublie-reussi.php');
	    break;
	    }
	   else {
        header('Location:oublie.php?erreur=1');
	   }
    }
?>