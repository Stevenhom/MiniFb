<?php
    session_start();
    include('connection.php');
    $idmembre2=isset($_GET['idmembre'])? $_GET['idmembre']:'';
    $sql="INSERT INTO amis(idmembre1, idmembre2, dateheuredemande) VALUES('%s', '%s', current_timestamp)";
    $sql=sprintf($sql,$_SESSION['id'], $idmembre2);
    $result=mysqli_query($bdd, $sql);
    header('Location: amis.php');
 ?>
