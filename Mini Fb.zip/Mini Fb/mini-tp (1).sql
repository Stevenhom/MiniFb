﻿drop database minifb;

/*début*/
CREATE DATABASE minifb;
USE minifb;

CREATE TABLE membres
(
    idmembre INT AUTO_INCREMENT,
    image VARCHAR(250),
    email VARCHAR(50),
    motdepasse VARCHAR(50),
    nom VARCHAR(250),
    datenaissance DATE,
    PRIMARY KEY(idmembre) 
)   ENGINE=InnoDB;

CREATE TABLE amis 
(
    idmembre1 INT,
    idmembre2 INT,
    image1 VARCHAR(250),
    image2 VARCHAR(250),
    dateheuredemande DATETIME,
    dateheureacceptation DATETIME,
    FOREIGN KEY (idmembre1) REFERENCES membres(idmembre),
    FOREIGN KEY (idmembre2) REFERENCES membres(idmembre),
    PRIMARY KEY (idmembre1, idmembre2)
);

CREATE TABLE publications
(   
    idpublication INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    dateheurepublication DATETIME,
    textepublication longtext,
    typeaffichage CHAR(6),
    idmembre INT,
    sentiment VARCHAR(20),
    FOREIGN KEY(idmembre) REFERENCES membres(idmembre) 
);

CREATE TABLE commentaires
(
    idcommentaires INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    dateheurecommentaires DATETIME,
    textecommentaire longtext,
    idpublication INT NOT NULL,
    FOREIGN KEY(idpublication) REFERENCES publications(idpublication),
    idmembre INT NOT NULL,
    FOREIGN KEY(idmembre) REFERENCES membres(idmembre)
);

CREATE TABLE typereaction
(
    idtype INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    typer VARCHAR(20) UNIQUE
);

CREATE TABLE reactions
(
    idtypereaction INT NOT NULL,
    idpublication INT NOT NULL,
    idmembre INT NOT NULL,
    FOREIGN KEY(idpublication) REFERENCES publications(idpublication),
    FOREIGN KEY(idmembre) REFERENCES membres(idmembre),
    FOREIGN KEY(idtypereaction) REFERENCES typeReaction(idtype),
    CONSTRAINT UNIQUE(idpublication, idmembre)
);

INSERT INTO membres VALUES('1','','abdolbak@email.com','111111','Abdoul Bakar','1998-02-22');
INSERT INTO membres VALUES('2','','brandonlee@email.com','222222','Leevan Brandon','2001-11-02');
INSERT INTO membres VALUES('3','','mangatiana@gmail.com','ronaldo','Mangatiana','2002-03-23');
INSERT INTO membres VALUES('4','','steven@yahoo.fr','nevets','Steven','2001-08-15');

/*mot de passe oublié*/
UPDATE membres SET motdepasse='maldini' WHERE email='mangatiana@gmail.com';

/*afficher liste des membres*/
SELECT * FROM membres;



INSERT INTO amis(idmembre1, idmembre2, dateheuredemande) VALUES('%s', '%s', current_timestamp);

UPDATE amis SET dateheureacceptation=current_timestamp WHERE idmembre1='%s' AND idmembre2='%s';

DELETE FROM amis WHERE idmembre1='%s' AND idmembre2='%s';