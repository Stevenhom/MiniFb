<?php
	include('connection.php');
	session_start();
	$_SESSION['idmembre']=$_POST['idmembre'];
	$idmembre=$_SESSION['idmembre'];
	$_SESSION['motdepasse']=$_POST['motdepasse'];
	$motdepasse=$_SESSION['motdepasse'];
	$_SESSION['motdepasseconf']=$_POST['motdepasseconf'];
	$motdepasseconf=$_SESSION['motdepasseconf'];
	$_SESSION['email']=$_POST['email'];
	$email=$_SESSION['email'];
	$_SESSION['nom']=$_POST['nom'];
	$nom=$_SESSION['nom'];
	$_SESSION['datenaissance']=$_POST['datenaissance'];
	$datenaissance=$_SESSION['datenaissance'];
	$sql="SELECT * FROM membres;";
	$result=mysqli_query($bdd, $sql);
	while($row=mysqli_fetch_assoc($result)) {
		if($email==$row['email'] || ($motdepasse!=$motdepasseconf) || $email=='') {
		header('Location:inscription.php?erreur=1');
		break;
		}
		else {
		header('Location:inscription-reussi.php');
		}
	}
?>