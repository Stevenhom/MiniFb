<?php 
	include('connection.php');
	session_start();
	$email=$_SESSION['email'];
	$image=$_FILES['avatar']['name'];
	$sql="UPDATE membres SET image='%s' WHERE email='%s';";
    $sql=sprintf($sql, $image, $email);
    $result=mysqli_query($bdd, $sql);
    header('Location:accueil.php');
?>