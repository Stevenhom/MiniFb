<?php
    session_start();
    include('connection.php');
    $idmembre2=isset($_GET['idmembre'])? $_GET['idmembre']:'';
    $sql="DELETE FROM amis WHERE idmembre1='%s' AND idmembre2='%s'";
    $sql=sprintf($sql,$_SESSION['id'],$IdMembre2);
    $result=mysqli_query($bdd,$sql);
    header('Location: amis.php');
 ?>
