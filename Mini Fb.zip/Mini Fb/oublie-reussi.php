<?php
    include('connection.php');
    session_start();
    $email=$_SESSION['email'];
    $motdepasse=$_SESSION['motdepasse'];
    $motdepasseconf=$_SESSION['motdepasseconf'];
    $sql="UPDATE membres SET motdepasse='%s' WHERE email='%s';";
    $sql=sprintf($sql, $motdepasse, $email);
	$result=mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Mot de passe oublie</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
    <h1>Mini Facebook</h1>
        <p><a href="listedemembres.php">La liste des membres</a></p>
        <h2>Changer de mot de passe</h2>
        <p>Votre mot de passe a été changé,<a href="login.php">cliquer ici pour vous reconnecter</a></p>
        <p><a href="login.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>