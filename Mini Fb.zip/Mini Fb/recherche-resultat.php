<?php
    include('connection.php');
	$nom=isset($_GET['nom'])? $_GET['nom']: '';
	$sql="SELECT * FROM membres WHERE nom LIKE '%s'";
	$sql=sprintf($sql, "%".$nom."%");
	$rep=mysqli_query($bdd, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Mini Facebook</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
    <h1>Mini Facebook</h1>
    <h2>Rechercher un membre</h2>
    <p><a href="recherche.php"><< Retour</a></p>
    <h3>Votre recherche : <?php echo $nom ?></h3>
    <table width="400" border="1" cellspacing="0">
		<tr>
		    <th>Resultats de recherche</th>
		</tr>
		<?php while ($row = mysqli_fetch_assoc($rep)) { ?>
			<tr>
                <td><?php echo $row['nom'] ?></td>
			</tr>
		<?php } ?>
	</table>
    <p><a href="accueil.php"><< Retour à l'accueil</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>