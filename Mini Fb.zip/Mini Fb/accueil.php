<?php
    include('connection.php');
	session_start();
	$email=$_SESSION['email'];
	$motdepasse=$_SESSION['motdepasse'];
	$sql="SELECT * FROM membres WHERE email='%s';";
	$sql=sprintf($sql, $email);
	$result=mysqli_query($bdd, $sql);
	$row=mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Accueil</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
       <h1>Mini Facebook</h1>
       <h2>Bienvenue dans votre compte</h2>
		<p>id Membre : <?php echo $row['idmembre']; ?></p>
        <p><img src="<?php echo $row['image']; ?>" width="100px"></p>
		<p>Nom : <?php echo $row['nom']; ?></p>
        <p><a href="img.php">Choisir votre avatar</a></p>
        </br>
        <p><a href="recherche.php">Rechercher un membre</a></p>
        <p><a href="amis.php">Amis</a></p>
        <p><a href="chat.php">Message</a></p>
        <p><a href="publications.php">Publications</a></p>
        </br>
        <p><a href="deconnect.php">Déconnecter</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>