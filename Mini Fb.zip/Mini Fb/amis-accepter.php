<?php
    session_start();
    include('connection.php');
    $idmembre1=isset($_GET['idmembre'])? $_GET['idmembre']:'';
    $sql="UPDATE amis SET dateheureacceptation=current_timestamp WHERE idmembre1='%s' AND IdMembre2='%s'";
    $sql=sprintf($sql, $idmembre1, $_SESSION['id']);
    $result=mysqli_query($bdd,$sql);
    header('Location: amis.php');
 ?>
