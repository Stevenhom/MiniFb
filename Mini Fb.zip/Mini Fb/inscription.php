<?php
    include('connection.php');
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>S'inscrire Mini Facebook</title>
        <link href="css/bootstrap.css" rel="stylesheet"> 
        <link href="style.css" rel="stylesheet">
        <link rel="icon" type="image/jpg" href="icon.jpg">
    </head>

    <body>
        <h1>Mini Facebook</h1>
        <p><a href="listedemembres.php">La liste des membres</a></p>
        <h2>Inscription</h2>
        <form action="inscription-traitement.php" method="post">
            <p> <?php if(isset($_GET['erreur'])) { ?>
                    Veuillez réeesayer
                <?php }  ?>
            </p>
            <p>email : <input type="text" name="email"></p>
            <p>mot de passe : <input type="password" name="motdepasse"></p>
            <p>confirmer mot de passe : <input type="password" name="motdepasseconf"></p>
            <p>nom : <input type="text" name="nom"></p>
            <p>date de naissance : <input type="text" name="datenaissance">(AAAA-MM-JJ)</p>
        <p><input type="submit" value="S'inscrire"></p>
        </form>
        <p><a href="login.php"><< Retour</a></p>
    <script src="js/jquery.js"></script> 
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>